'use strict';

addressBtn.onclick = getCoords;
squareBtn.onclick = filterSquare;

var arrAddress = ['Киев, Никольско-Слободская 31',
                  'Киев, Никольско-Слободская 33',
                  'Киев, Героев майдана 36',
                  'Киев, Парк Шевченко',
                  'Киев, Контрактова площа'],
    exitAddress = [],
    inRadius = [],
    squareCoords = {
      lat: null,
      lng: null
    };
// exitAddress = [['адрес', 'latitude', 'longitude'], [...]]

function getCoords() {
  for (var key in arrAddress) {
    var url = ['http://maps.google.com/maps/api/geocode/json?address=',arrAddress[key],key];
    exitAddress.push([arrAddress[key]]);
    ajaxGetReq(url, showRes);
  }
  console.log(exitAddress)
}

function showRes(xhr, curAdr, key) {
  var address = JSON.parse(xhr.responseText);
  address = address.results[0].geometry.location;

  if (curAdr) {
    exitAddress[key].push(address.lat);
    exitAddress[key].push(address.lng);
  } else {
    squareCoords.lat = address.lat;
    squareCoords.lng = address.lng;
    console.log(squareCoords);
    for (var key in exitAddress) {
      var myLatLngOne = new google.maps.LatLng({lat: Number(exitAddress[key][1].toFixed(7)), lng: Number(exitAddress[key][2].toFixed(7))}),
          myLatLngTwo = new google.maps.LatLng({lat: squareCoords.lat, lng: squareCoords.lng}),
          distance = google.maps.geometry.spherical.computeDistanceBetween(myLatLngOne, myLatLngTwo);
      if (distance <= 3000) {
        inRadius.push(exitAddress[key][0])
      }
    }
    console.log(inRadius)
  }
}

function filterSquare() {
  var url = 'http://maps.google.com/maps/api/geocode/json?address=Киев, Майдан';
  ajaxGetReq(url, showRes);
}

function ajaxGetReq(url, callback) {
  var xhr = new XMLHttpRequest();
  if (url instanceof Array) {
    xhr.open('GET', url[0] + url[1], true);
  } else {
    xhr.open('GET', url, true);
  }
  xhr.send();

  xhr.onreadystatechange = function() {
    if (xhr.readyState != 4) return;

    if (xhr.status != 200) {
      console.log(xhr.status + ': ' + xhr.statusText);
    } else {
      if (url instanceof Array) {
        callback(xhr, url[1], url[2]);
      } else {
        callback(xhr);
      }
    }
  }
}